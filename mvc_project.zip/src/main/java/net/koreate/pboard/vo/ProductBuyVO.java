package net.koreate.pboard.vo;

import java.util.Date;

import lombok.Data;

@Data
public class ProductBuyVO {

	private int pbno;
	private int psno;
	private int pno;
	private int uno;
	private Date regdate;
	
}
