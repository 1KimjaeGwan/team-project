package net.koreate.pboard.vo;

import lombok.Data;

@Data
public class ProductImgVO {
	
	private int pino;
	private int pno;
	private String img_name;

}
