package net.koreate.sboard.vo;

import lombok.Data;

@Data
public class LikeVO {
	
	private int sno;
	private int uno;
}
