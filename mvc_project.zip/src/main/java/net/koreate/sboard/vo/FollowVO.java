package net.koreate.sboard.vo;

import lombok.Data;

@Data
public class FollowVO {
	
	private int uno;
	private int ufollower;
	
	
	private String uid;
	private String unick;
	private String user_img;
	
	private int totalCount;
}
