package net.koreate.user.vo;

import lombok.Data;

@Data
public class BanVO {

	private String uid;
	private int bandate;
	private int defaultint;
	
}
