package net.koreate.user.vo;

import lombok.Data;

@Data
public class AuthVO {
	
	private String uid;		// 사용자
	private String uauth;		// 권한
	
}
